package com.example.samleffler.lefflerfinal;

public class pizzaPlace {
    private String location;
    private String url;

    private void setPizzaInfo(Integer i){
        switch (i){
            case 0: //thick
                location="Back Country Pizza";
                url="https://backcountrypizzaandtaphouse.info/";
                break;
            case 1: //thin
                location="Pizzareia Locale";
                url="https://localeboulder.com/";
                break;
            case 2: //gluten free
                location="Boss Lady Pizza";
                url="https://bossladypizza.com/";
                break;

            default:
                location="none";
                url="https://google.com/";
        }
    }

    public void setPizzaPlace(Integer i){

        setPizzaInfo(i);
    }

    public void setPizzaURL(Integer i){

        setPizzaInfo(i);
    }

    public String getPizzaPlace(){

        return location;
    }

    public String getPizzaURL(){

        return url;
    }

//
}