package com.example.samleffler.lefflerfinal;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.VisibleForTesting;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {
    private EditText pizzaName;
    private ToggleButton sauce;
    private Switch gluten;
    private Spinner size;
    private CheckBox pepperoni;
    private CheckBox sausage;
    private CheckBox mushroom;
    private CheckBox onion;
    private RadioGroup crusts;
    private Button goButton;
    private TextView message;
    private Button suggestButton;
    private pizzaPlace myPizzaPlace = new pizzaPlace();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //get button
         goButton = findViewById(R.id.button);
        //create listener
        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick(View view){
                pizza(view);
            }
        };
        //add listener to the button
        goButton.setOnClickListener(onclick);

        //get button
        suggestButton = findViewById(R.id.findPlace);
        //create listener
        View.OnClickListener onclick2 = new View.OnClickListener(){
            public void onClick(View view){
                findPizzaPlace(view);
            }
        };
        //add listener to the button
        suggestButton.setOnClickListener(onclick2);
    }

    private void pizza(View view){
        message = findViewById(R.id.textView);

        pizzaName = findViewById(R.id.editText);
        size = findViewById(R.id.spinner);
        Integer pizzaSize = size.getSelectedItemPosition();
        String[] sizeOptions = getResources().getStringArray(R.array.sizes);
        sauce = findViewById(R.id.toggleButton);
        Boolean pizzaSauce = sauce.isChecked();
        String sauceChoice = " ";
        if (pizzaSauce){
            sauceChoice = getResources().getString(R.string.red);
        }

        else{
            sauceChoice = getResources().getString(R.string.white);
        }
        gluten = findViewById(R.id.switch1);
        Boolean pizzaGluten =gluten.isChecked();
        String glutenChoice = " ";
        if (pizzaGluten){
            glutenChoice = getResources().getString(R.string.gluten);
        }

        else{
            glutenChoice = getResources().getString(R.string.gluten2);
        }
        crusts = findViewById(R.id.radioGroup);
        RadioButton pickedCrust = findViewById(crusts.getCheckedRadioButtonId());

        pepperoni = findViewById(R.id.checkBox);
        mushroom = findViewById(R.id.checkBox2);
        sausage = findViewById(R.id.checkBox3);
        onion = findViewById(R.id.checkBox4);

        if (pizzaName.getText().toString().isEmpty() || pickedCrust.getText().toString().isEmpty()){
            Context context = getApplicationContext();
            CharSequence text = getString(R.string.toast);
            int duration = Toast.LENGTH_SHORT;
            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        }

        else{
            String name = pizzaName.getText().toString();
            String pizzaCrust = pickedCrust.getText().toString();
            String pizzaMessage = String.format(getResources().getString(R.string.message), name, sizeOptions[pizzaSize], glutenChoice, pizzaCrust, sauceChoice);
            if (pepperoni.isChecked()){
                pizzaMessage += ", " + getResources().getString(R.string.pepperoni);
            }
            if (mushroom.isChecked()){
                pizzaMessage += ", " + getResources().getString(R.string.mushroom);
            }
            if (sausage.isChecked()){
                pizzaMessage += ", " + getResources().getString(R.string.sausage);
            }
            if (onion.isChecked()){
                pizzaMessage += ", " + getResources().getString(R.string.onion);
            }
            message.setText(pizzaMessage);
        }


    }

    private void findPizzaPlace(View view){
        gluten = findViewById(R.id.switch1);
        Boolean pizzaGluten =gluten.isChecked();
        crusts = findViewById(R.id.radioGroup);
        RadioButton pickedCrust = findViewById(crusts.getCheckedRadioButtonId());

        if (pickedCrust == null){
            Context context = getApplicationContext();
            CharSequence text = getString(R.string.toast);
            int duration = Toast.LENGTH_SHORT;
            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        }

        else{
            String pizzaCrust = pickedCrust.getText().toString();

            if (pizzaGluten){
                myPizzaPlace.setPizzaPlace(2);

                //create an Intent
                Intent intent = new Intent(this, suggestPizza.class);
                String suggestedPizzaPlace = myPizzaPlace.getPizzaPlace();
                String suggestedPizzaURL = myPizzaPlace.getPizzaURL();
                //pass data
                intent.putExtra("pizzaPlaceName", suggestedPizzaPlace);
                intent.putExtra("pizzaPlaceURL", suggestedPizzaURL);

                //start intent
                startActivity(intent);
            }

            else{
                if (pizzaCrust.equals(getResources().getString(R.string.thick))){
                    myPizzaPlace.setPizzaPlace(0);

                    //create an Intent
                    Intent intent = new Intent(this, suggestPizza.class);
                    String suggestedPizzaPlace = myPizzaPlace.getPizzaPlace();
                    String suggestedPizzaURL = myPizzaPlace.getPizzaURL();
                    //pass data
                    intent.putExtra("pizzaPlaceName", suggestedPizzaPlace);
                    intent.putExtra("pizzaPlaceURL", suggestedPizzaURL);

                    //start intent
                    startActivity(intent);
                }

                else{
                    myPizzaPlace.setPizzaPlace(1);

                    //create an Intent
                    Intent intent = new Intent(this, suggestPizza.class);
                    String suggestedPizzaPlace = myPizzaPlace.getPizzaPlace();
                    String suggestedPizzaURL = myPizzaPlace.getPizzaURL();
                    //pass data
                    intent.putExtra("pizzaPlaceName", suggestedPizzaPlace);
                    intent.putExtra("pizzaPlaceURL", suggestedPizzaURL);

                    //start intent
                    startActivity(intent);
                }
            }
        }



    }
}
