package com.example.samleffler.lefflerfinal;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class suggestPizza extends AppCompatActivity {
    private String pizzaPlaceName;
    private String pizzaPlaceURL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_suggest_pizza);

        //get intent
        Intent intent = getIntent();
        pizzaPlaceName = intent.getStringExtra("pizzaPlaceName");
        pizzaPlaceURL = intent.getStringExtra("pizzaPlaceURL");

        TextView messageView = findViewById(R.id.suggestion);
        messageView.setText(String.format(getResources().getString(R.string.message2), pizzaPlaceName));

        //get image button
        ImageButton imageButton = findViewById(R.id.imageButton);
        //create listener
        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick(View view){
                loadSite(view);
            }
        };

        //add listener to the button
        imageButton.setOnClickListener(onclick);
    }

    private void loadSite(View view){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(pizzaPlaceURL));
        startActivity(intent);
    }
}
