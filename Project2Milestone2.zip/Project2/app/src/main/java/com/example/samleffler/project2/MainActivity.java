package com.example.samleffler.project2;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    private int PICK_IMAGE_REQUEST = 1;
    TextView dimensionsMessage;
    TextView physicalMessage;
    EditText inputDPI;
    Button goButton;
    float w;
    float h;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //create listener
        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick(View view){
                loadImage(view);
            }
        };
        View.OnClickListener goClick = new View.OnClickListener(){
            public void onClick(View view){
                calculate(view);
            }
        };
        Button loadButton = findViewById(R.id.loadButton);
        goButton = findViewById(R.id.goButton);
        dimensionsMessage = findViewById(R.id.dimensions);
        physicalMessage = findViewById(R.id.printSize);
        inputDPI = findViewById(R.id.enterDPI);

        //add listener to the button
        loadButton.setOnClickListener(onclick);
        goButton.setOnClickListener(goClick);
    }


    //loading image based on this tutorial: http://codetheory.in/android-pick-select-image-from-gallery-with-intents/
    private void loadImage(View view){
        Intent intent = new Intent();
        // Show only images, no videos or anything else
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        // Always show the chooser (if there are multiple options available)
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {

            Uri uri = data.getData();

            try {
               Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
                // Log.d(TAG, String.valueOf(bitmap));


                w = bitmap.getWidth();
                h = bitmap.getHeight();
                ImageView imageView = (ImageView) findViewById(R.id.imageView);

                if (w > 2048 && h>2048){
                    imageView.setImageResource(R.drawable.big);
                }
                else{
                    imageView.setImageBitmap(bitmap);
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
        }


    }

    private void calculate (View view){

        if(w == 0.0f || h == 0.0f){
            Context context = getApplicationContext();
            CharSequence text = "Choose an Image";
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        }

        else{
            String dpiText = inputDPI.getText().toString();
            if (TextUtils.isEmpty(dpiText)){
                Context context = getApplicationContext();
                CharSequence text = "Enter a dpi value";
                int duration = Toast.LENGTH_SHORT;

                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
            }
            else{
                float dpi = Float.parseFloat(dpiText);
                float pw = w/dpi;
                float ph = h/dpi;


                String sizeMessage =  String.format(getResources().getString(R.string.size), w, h);
                String printMessage =  String.format(getResources().getString(R.string.printSize), pw, ph);

                dimensionsMessage.setText(sizeMessage);
                physicalMessage.setText(printMessage);
            }
        }


    }
}
