package com.example.samleffler.lab6;

import android.app.Activity;
import android.media.Image;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;



public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }





    public void calculate(View view) {
        Spinner shapeSpinner = findViewById(R.id.spinner);
        String currentShape = shapeSpinner.getSelectedItem().toString();
        EditText widthInput = findViewById(R.id.width);
        double width = Double.parseDouble(widthInput.getText().toString());
        EditText heightInput = findViewById(R.id.height);
        double height = Double.parseDouble(heightInput.getText().toString());
        CheckBox areaBox = findViewById(R.id.area);
        CheckBox perimeterBox = findViewById(R.id.perimeter);
        TextView output = findViewById(R.id.output);
        ImageView pic = findViewById(R.id.imageView);
        double area = 0;
        double perimeter = 0;

        if (currentShape.equals("Rectangle")) {
            pic.setImageResource(R.drawable.rect);
            if (areaBox.isChecked()) {
                area = width * height;
                output.append("Area: " + area + "\n");
            }
            if (perimeterBox.isChecked()) {
                perimeter = 2 * width + 2 * height;
                output.append("Perimeter: " + perimeter + "\n");
            }
        }

            if (currentShape.equals("Ellipse")) {
                pic.setImageResource(R.drawable.ell);
                if (areaBox.isChecked()) {
                    area = width / 2 * height / 2 * Math.PI;
                    output.append("Area: " + area + "\n");
                }
                if (perimeterBox.isChecked()) {
                    double a = width / 2;
                    double b = height / 2;
                    perimeter = Math.PI * (a + b) * ((3 * (a - b) * (a - b)) / ((a + b) * (a + b) * (Math.sqrt(-3 * (((a - b) * (a - b)) / ((a + b) * (a + b))) + 4) + 10))+1 );
                    output.append("Circumference: " + perimeter + "\n");
                }
            }
        }


}

