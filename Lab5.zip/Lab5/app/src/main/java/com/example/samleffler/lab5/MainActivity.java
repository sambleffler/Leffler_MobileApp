package com.example.samleffler.lab5;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void checkChristmas(View view){
        TextView message = findViewById(R.id.textView);
        EditText date = findViewById(R.id.date);
        String dateValue = date.getText().toString();
        ImageView pic = findViewById(R.id.imageView);
        if (dateValue.equals("12/25")){
            message.setText("Yes, Merry Christmas!");
            pic.setImageResource(R.drawable.santa);
        }

        else{
            message.setText("No, Calm Down...");
            pic.setImageResource(R.drawable.grinch);
        }
    }
}
