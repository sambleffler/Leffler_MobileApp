package com.example.samleffler.project2;

        import android.content.Context;
        import android.content.Intent;
        import android.graphics.Bitmap;
        import android.graphics.BitmapFactory;
        import android.net.Uri;
        import android.provider.MediaStore;
        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.text.Editable;
        import android.text.TextUtils;
        import android.text.TextWatcher;
        import android.view.View;
        import android.widget.AdapterView;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.ImageButton;
        import android.widget.ImageView;
        import android.widget.Spinner;
        import android.widget.TextView;
        import android.widget.Toast;

        import java.io.FileInputStream;
        import java.io.IOException;

public class imageResultActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    private TextView dimensionsMessage;
    private TextView physicalMessage;
    private EditText inputDPI;
//    private Button goButton;
    private float w;
    private float h;
    private Bitmap bitmap;
    private String filename;
    private Intent intent;
    private Spinner units;

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        //save current state
        if(filename != null) {
            outState.putString("image", filename);

        }
        else{
            outState.putFloat("width", w);
            outState.putFloat("height", h);

        }

        //always call the superclass so it can save the view hierarchy state
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //get intent
        intent = getIntent();

        if (intent.hasExtra("image")) {
           processImage();
        }

        else{
            w=intent.getFloatExtra("width",0);
            h=intent.getFloatExtra("height",0);
            String sizeMessage =  String.format(getResources().getString(R.string.size), w, h);
            dimensionsMessage = findViewById(R.id.digitalLabel);
            dimensionsMessage.setText(sizeMessage);
        }



//        goButton = findViewById(R.id.goButton);
        dimensionsMessage = findViewById(R.id.digitalLabel);
        physicalMessage = findViewById(R.id.printLabel);
        inputDPI = findViewById(R.id.enterDPI);
        units = findViewById(R.id.unitsSpinner);

        //create listener
//        View.OnClickListener goClick = new View.OnClickListener(){
//            public void onClick(View view){
//                calculate();
//            }
//        };
        //add listener to the button
//        goButton.setOnClickListener(goClick);
        inputDPI.addTextChangedListener(new TextWatcher(){
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override
            public void afterTextChanged(Editable s) {

                if (s.length() > 0) {
                    calculate();
                }
            }
        });
        units.setOnItemSelectedListener(this);

    }




    private void calculate (){


        String dpiText = inputDPI.getText().toString();
        if (TextUtils.isEmpty(dpiText)){
            Context context = getApplicationContext();
            CharSequence text = getString(R.string.enterDPI);
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        }
        else{
            float dpi = Float.parseFloat(dpiText);
            float pw;
            float ph;
            String sizeMessage;
            String printMessage;

            String chosenUnit = units.getSelectedItem().toString();
//            String[] options = getResources().getStringArray(R.array.units);
            switch (chosenUnit){
                case "inches":
                    pw = w/dpi;
                    ph = h/dpi;
                    sizeMessage =  String.format(getResources().getString(R.string.size), w, h);
                    printMessage =  String.format(getResources().getString(R.string.printSizeIn), pw, ph);
                    break;
                case "feet":
                    pw = w/dpi/12;
                    ph = h/dpi/12;
                    sizeMessage =  String.format(getResources().getString(R.string.size), w, h);
                    printMessage =  String.format(getResources().getString(R.string.printSizeFt), pw, ph);
                    break;
                case "millimeters":
                    pw = (float)(w/dpi * 25.4);
                    ph = (float)(h/dpi * 25.4);
                    sizeMessage =  String.format(getResources().getString(R.string.size), w, h);
                    printMessage =  String.format(getResources().getString(R.string.printSizeMm), pw, ph);
                    break;
                case "meters":
                    pw = (float) (w/dpi * .0254);
                    ph = (float) (h/dpi * .0254);
                    sizeMessage =  String.format(getResources().getString(R.string.size), w, h);
                    printMessage =  String.format(getResources().getString(R.string.printSizeM), pw, ph);
                    break;
                default:
                    pw = w/dpi;
                    ph = h/dpi;
                    sizeMessage =  String.format(getResources().getString(R.string.size), w, h);
                    printMessage =  String.format(getResources().getString(R.string.printSizeIn), pw, ph);
                    break;
            }



            dimensionsMessage.setText(sizeMessage);
            physicalMessage.setText(printMessage);
        }



    }

    private void processImage(){
        // converting byte array found here: https://stackoverflow.com/questions/11010386/passing-android-bitmap-data-within-activity-using-intent-in-android
        filename = intent.getStringExtra("image");
        try {
            FileInputStream is = this.openFileInput(filename);
            bitmap = BitmapFactory.decodeStream(is);
            is.close();
            w = bitmap.getWidth();
            h = bitmap.getHeight();
            ImageView imageView = (ImageView) findViewById(R.id.imageView);

            if (w > 2048 && h>2048){
                imageView.setImageResource(R.drawable.big);
            }
            else{
                imageView.setImageBitmap(bitmap);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        if (inputDPI.getText().toString().length() >0){
            calculate();
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
