package com.example.samleffler.project2;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    private int PICK_IMAGE_REQUEST = 1;
    private Button loadImageButton;
    private Button pixelButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intro);
        loadImageButton = findViewById(R.id.loadButton);
        View.OnClickListener loadClick = new View.OnClickListener(){
            public void onClick(View view){
                loadImage();
            }
        };

        loadImageButton.setOnClickListener(loadClick);

        pixelButton = findViewById(R.id.button2);
        View.OnClickListener pixelClick = new View.OnClickListener(){
            public void onClick(View view){
                sendDimensions();
            }
        };
        pixelButton.setOnClickListener(pixelClick);
    }

    //loading image based on this tutorial: http://codetheory.in/android-pick-select-image-from-gallery-with-intents/
    private void loadImage(){
        Intent intent = new Intent();
        // Show only images, no videos or anything else
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        // Always show the chooser (if there are multiple options available)
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }

    private void sendDimensions(){
        EditText widthInput = findViewById(R.id.editWidth);
        EditText heightInput = findViewById(R.id.editHeight);

        if (TextUtils.isEmpty(widthInput.getText().toString()) || TextUtils.isEmpty(heightInput.getText().toString())){
            Context context = getApplicationContext();
            CharSequence text = getString(R.string.enterWH);
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        }

        else{
            float w = Float.parseFloat(widthInput.getText().toString());
            float h = Float.parseFloat(heightInput.getText().toString());
            Intent intent= new Intent(this, imageResultActivity.class);
            intent.putExtra("width", w);
            intent.putExtra("height", h);
            startActivity(intent);
        }


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);



        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {

            Uri uri = data.getData();
            //create an Intent


            try {
                Intent imageIntent = new Intent(this, imageResultActivity.class);
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
                // Log.d(TAG, String.valueOf(bitmap));

                //Write file
                String filename = "bitmap.png";
                FileOutputStream stream = this.openFileOutput(filename, Context.MODE_PRIVATE);
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);

                //Cleanup
                stream.close();
                bitmap.recycle();

                //pass data
                imageIntent.putExtra("image", filename);

                //start intent
                startActivity(imageIntent);




            } catch (IOException e) {
                e.printStackTrace();
            }
        }


    }
}