package com.example.samleffler.lab7;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

public class CheckActivity extends AppCompatActivity {

    private int input;
    private int correct;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check);

        //get intent
        Intent intent = getIntent();
        input = intent.getIntExtra("guess",0);
        correct = intent.getIntExtra("answer",0);

        Button helpButton = findViewById(R.id.helpButton);

        TextView message =findViewById(R.id.message);
        if (input == correct){
            message.setText(R.string.correct);
            helpButton.setVisibility(View.GONE);
        }
        else{
            String incorrectMessage =  String.format(getResources().getString(R.string.incorrect), input, correct);

            message.setText(incorrectMessage);
        }


        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick(View view){
                loadVideo(view);
            }
        };
        helpButton.setOnClickListener(onclick);

    }
    private void loadVideo(View view){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse("https://www.youtube.com/watch?v=O7PiTAGtBNk&vl=en"));
        startActivity(intent);
    }
}
